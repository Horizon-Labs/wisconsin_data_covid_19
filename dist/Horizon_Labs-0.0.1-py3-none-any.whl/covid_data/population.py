def hello():
    print("Hello")